#### SharpDist - ESP32 Arduino library for Sharp 2Y0A21 IR distance sensor.

### How to use
The SharpDist library implements a class called SharpDist.
In order to read IR, create a SharpDist object.
The constructor takes one argument - a pin number.
Example:
```C++
SharpDist dist(36);
```
In addition, an optional second argument to the constructor allows collecting multiple sensor readings and averaging them together to get the distance.
The value of this second argument is the number of readings to average.
Example:
```C++
SharpDist dist(36, 10);
```

### Function List
* `void SharpDist::setSamples(int samples)` - sets the number of samples to average (default: 1)
* `float SharpDist::distanceInches()` - gets the distance in inches
* `float SharpDist::distanceCentimeters()` - gets the distance in centimeters

### **NOTE:** Sensor Curve
Due to the angles of the path of light, the distance values will start to increase once you get below ~8cm of distance. This is not fixable. Also, if the sensor is completely unable to detect anything, a distance of infinity centimeters may be returned.
